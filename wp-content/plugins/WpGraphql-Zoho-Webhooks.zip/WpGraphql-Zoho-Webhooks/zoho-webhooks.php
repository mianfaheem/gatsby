<?php 
/**
 * Plugin Name:       Zoho Webhooks
 * Description:       Webhooks to create, delete or update data
 * Version:           1.0
 * Requires at least: 5.2 
 * Requires PHP:      7.2
 * Author:            Wali ur Rehman
 *
 **/

// To Delete Ticket
add_action('init','delete_ticket');
function delete_ticket(){
  register_rest_route('/api/v1/','deleteTicket',array('method'=>'DELETE','callback'=>'deleteTicket'));
}

function deleteTicket()
{
  $data=array();
  $data['status']='OK';
  $data['message']='You have reached the server';
  return  http_response_code(200);
}

// To Update Ticket
add_action( 'init', 'update_ticket' );
function update_ticket(){
  register_rest_route('/api/v1/','updateTicket',array('method'=>'PATCH','callback'=>'updateTicket'));
}
function updateTicket($data)
{
  global $wpdb; 
  $ticket=array();
  $ticket['subject']=$data[1]->payload->subject;
  $ticket['description']=$data[1]->payload->description;
  $ticket['priority']=$data[1]->payload->priority;
	$wpdb->update('wp_zoho_tickets', $ticket, array( 'id' =>$data[1]->payload->id ));

  return  http_response_code(200);
}


// To Create Ticket
add_action( 'init', 'create_ticket' );
function create_ticket(){
  register_rest_route('/api/v1/','createTicket',array('method'=>'PATCH','callback'=>'createTicket'));
}
function createTicket()
{
  $data=array();
  $data['status']='OK';
  $data['message']='You have reached the server';
  return  http_response_code(200);
}
